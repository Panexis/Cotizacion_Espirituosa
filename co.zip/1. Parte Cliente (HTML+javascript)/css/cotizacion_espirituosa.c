/*
	Nuevo css
	
	*/
.td {
	height: auto;
	padding: 0; 
	margin: 0;
}