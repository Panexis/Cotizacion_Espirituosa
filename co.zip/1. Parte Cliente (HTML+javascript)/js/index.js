
//Incluir los javascripts de los que dependo
document.write(
	'<script src="./js/global.js" type="text/javascript"></script>'+
	'<script src="./js/jquery.js" type="text/javascript"></script>'+
	'<script src="./js/bootstrap.js" type="text/javascript"></script>'+
	'<script src="./js/database.js" type="text/javascript" charset="utf-8"></script>'+
	'<script src="./js/stock.js" type="text/javascript" charset="utf-8"></script>'+
	'<script src="./js/servicios.js" type="text/javascript" charset="utf-8"></script>'+
	'<script src="./js/cotizacion.js" type="text/javascript" charset="utf-8"></script>'+
	'<script src="./js/servidor.js" type="text/javascript" charset="utf-8"></script>'+
	'<script src="./js/eventos.js" type="text/javascript" charset="utf-8"></script>');
	
var ArrayGruposBebida = [];
var ArrayTiposServicio = [];
	

function MostrarOpcionesxDefecto(){
	db.EjecutarSQL("SELECT Nombre, Valor FROM Propiedades"
		,	function(bExito, rowsArray){
			//mostrar en los precios por defecto en un div
			var html = "";
			for(var i = 0; i<rowsArray.length; i++)
				$("#Id_"+rowsArray[i][0]).val(rowsArray[i][1]);

		});
}

/********************** Tipos de Servicio ***********************/

function MostrarTiposServicio(){
	servicios.ListarTiposServicios(
		function(bExito, rowsArray){
			if(!bExito){
				return;
			}
			ArrayTiposServicio = rowsArray;
			$("#tabla_Tipos_Servicio").html("");
			$(".Select_Tipos_Servicio").html("");
			for(var i = 0; i < ArrayTiposServicio.length; i++){
				//vamos a rellenar la tabla de tipos de servicios
				$("#tabla_Tipos_Servicio").append('<tr> '+
								'<td><input type="text" id="Id_'+ArrayTiposServicio[i][0]+'_Nombre" value="'+ArrayTiposServicio[i][1]+'"></td> '+
								'<td><input type="text" id="Id_'+ArrayTiposServicio[i][0]+'_Cantidad" value="'+ArrayTiposServicio[i][2]+'" class="input-mini numerico"></td> '+
								'<td><input type="text" id="Id_'+ArrayTiposServicio[i][0]+'_Precio" value="'+ArrayTiposServicio[i][3]+'" class="input-mini numerico"></td> '+
								'<td><input type="text" id="Id_'+ArrayTiposServicio[i][0]+'_Maximo" value="'+ArrayTiposServicio[i][4]+'" class="input-mini numerico"></td> '+
								'<td><input type="text" id="Id_'+ArrayTiposServicio[i][0]+'_Minimo" value="'+ArrayTiposServicio[i][5]+'" class="input-mini numerico"></td> '+
								'<td><input type="text" id="Id_'+ArrayTiposServicio[i][0]+'_Tramo" value="'+ArrayTiposServicio[i][6]+'" class="input-mini numerico"></td> '+
								'<td class="boton" ><a class="btn" onClick="ModificarTiposServicios('+ArrayTiposServicio[i][0]+')"  href="javascript:void(0)"><i class="icon-refresh"></i> </a><a class="btn" onClick="EliminarTipoServicio('+ArrayTiposServicio[i][0]+')" href="javascript:void(0)"><i class="icon-minus"></i> </a></td> '+
							'</tr>  '
							);
				//a�adir los elementos del selector
				
				$(".Select_Tipos_Servicio").append('<option value="'+ArrayTiposServicio[i][0]+'" ' + (ArrayTiposServicio[i][0] == $(".Select_Tipos_Servicio").attr("name") ? "selected=selected" : "") +" >"+ArrayTiposServicio[i][1]+"</option>");
				
			}
			$("#tabla_Tipos_Servicio").append('<tr> '+  
					'<td><input type="text" id="Id_NuevoTS_Nombre" value=""></td>  '+
					'<td><input type="text" id="Id_NuevoTS_Cantidad" value="" class="input-mini numerico"></td> ' +
					'<td><input type="text" id="Id_NuevoTS_Precio" value="" class="input-mini numerico"></td> '+
					'<td><input type="text" id="Id_NuevoTS_Maximo" value="" class="input-mini numerico"></td> '+
					'<td><input type="text" id="Id_NuevoTS_Minimo" value="" class="input-mini numerico"></td> '+
					'<td><input type="text" id="Id_NuevoTS_Tramo" value="" class="input-mini numerico"></td> '+
					'<td class="boton" ><a class="btn" onClick="AnadirNuevoTipoServicio()" href="javascript:void(0)"><i class="icon-plus"></i> </a></td> '+
				'</tr> ');
			
	});
}

function RellenarSelectTiposServicio(){
	if(ArrayTiposServicio == [])
		MostrarTiposServicio();
	else{
		$(".Select_Tipos_Servicio").html("");
			for(var i = 0; i < ArrayTiposServicio.length; i++){
				$(".Select_Tipos_Servicio").append('<option value="'+ArrayTiposServicio[i][0]+'" ' + (ArrayTiposServicio[i][0] == $(".Select_Tipos_Servicio").attr("name") ? "selected=selected" : "") +" >"+ArrayTiposServicio[i][1]+"</option>");
			}
	}

}

function AnadirNuevoTipoServicio(){
	//Comprobar que haya datos en los campos copa y ml
	if($("#Id_NuevoTS_Nombre").val() == ""){
		alert("Debe indicar el nombre del tipo de servicio");
		return;
	}
	if($("#Id_NuevoTS_Cantidad").val() == ""){
		alert("Debe indicar la cantidad en ml que se gasta con este servicio");
		return;
	}
	
	//debo a�adir el tipo de servicio
	servicios.AnadirTiposServicio($("#Id_NuevoTS_Nombre").val(), $("#Id_NuevoTS_Cantidad").val()
	, function(bExito, idTipoServicio){
		if(!bExito){
			//
			alert("No se ha podido a�adir este tipo de servicio");
			return;
		}
		//Ha a�adido cotizaci�n inicial de este tipo de servicio?
		if($("#Id_NuevoTS_Precio").val() != null)
			cotizacion.AnadirPrecioxTipoServicio(idTipoServicio, $("#Id_NuevoTS_Precio").val(), $("#Id_NuevoTS_Maximo").val(), $("#Id_NuevoTS_Minimo").val(), $("#Id_NuevoTS_Tramo").val()
			,	function (bExito){
				MostrarTiposServicio();
			});			
		else
			MostrarTiposServicio();
		$("#Id_NuevoTS_Nombre").focus();
	});

}

function ModificarTiposServicios(idTipoServicio){
	servicios.ModificarTipoServicio(idTipoServicio, $("#Id_TS_"+idTipoServicio+"_Nombre").val(), $("#Id_TS_"+idTipoServicio+"_Cantidad").val()
		, function(bExito){
			if(!bExito){
				alert("No se ha podido modificar el tipo de servicio");
				return;
			}
			if($("#Id_TS_"+idTipoServicio+"_Precio").val()!=null)
				ComprobarSiExistePrecio(null, idTipoServicio
					, function(bExito){
						if(bExito)
							cotizacion.ModificarPrecio(null, idTipoServicio,$("#Id_NuevoTSPrecio").val(), $("#Id_NuevoTSMaximo").val(), $("#Id_NuevoTSMinimo").val(), $("#Id_NuevoTSTramo").val()
							,	function (bExito){
									MostrarTiposServicio();
							});
						else 
							cotizacion.AnadirPrecioxTipoServicio(idTipoServicio, $("#Id_NuevoTSPrecio").val(), $("#Id_NuevoTSMaximo").val(), $("#Id_NuevoTSMinimo").val(), $("#Id_NuevoTSTramo").val()
							,	function (bExito){
							MostrarTiposServicio();
							});
					});			
			else
				MostrarTiposServicio();
	});
}

function EliminarTipoServicio(idTipoServicio){
	servicios.QuitarTiposServicio(idTipoServicio
		, function(bExito){
			if(!bExito){
				alert("No se ha podido eliminar el tipo de servicio");
				return;
			}		
		MostrarTiposServicio();
	});
}

/**********************************************************************/

function MostrarGruposBebida(){
	stock.ListarGruposBebida(function(bExito, rowsArray){
		if(!bExito){
			return;
		}
		ArrayGruposBebida = rowsArray;
		//debo a�adir el grupo de bebidas que he recibido por el ArrayGruposBebida
		$("#tabla_Grupos_Bebida").html("");
		for(var i = 0; i<ArrayGruposBebida.length; i++){
			$("#tabla_Grupos_Bebida").append(
				'<tr id="TR_'+ArrayGruposBebida[i].idGrupoBebida+'"> '+
				'	<td><input type="text" id="Id_'+ArrayGruposBebida[i].idGrupoBebida+'_Nombre" value="'+ArrayGruposBebida[i].Nombre+'" class="input-block-level"></td>'+
				'	<td class="boton" ><a class="btn" onClick="ModificarGrupoBebida('+ArrayGruposBebida[i].idGrupoBebida+')"  href="javascript:void(0)"><i class="icon-refresh" ></i> </a><a class="btn" onClick="EliminarGrupoBebida('+ArrayGruposBebida[i].idGrupoBebida+')" href="javascript:void(0)"><i class="icon-minus"></i> </a></td>'+
				'<td style="text-align:left;">'+
				' <a class="m_GB" href="javascript:void(0)" onClick="mostrarOcultarBebida('+ArrayGruposBebida[i].idGrupoBebida+')">[ '+
				'<span id="mas_Bebidas_'+ArrayGruposBebida[i].idGrupoBebida+'">+</span> ] Bebidas</a>&nbsp;&nbsp;&nbsp;&nbsp;'+
				' <a class="m_GB" href="javascript:void(0)" onClick="mostrarOcultarTS('+ArrayGruposBebida[i].idGrupoBebida+')">[ '+
				'<span id="mas_TS_'+ArrayGruposBebida[i].idGrupoBebida+'">+</span> ] Precios por Tipo Servicios</a>'+
				'</td> '+
				'</tr></td>'+
				'<tr id="Id_TR_TS_'+ArrayGruposBebida[i].idGrupoBebida+'" style="display:none;">'+
				'<td></td><td colspan="2"><table class="in_tabla" style="min-width: 500px;">'+
				'<!-- <caption onClick="mostrarOcultarTS('+ArrayGruposBebida[i].idGrupoBebida+')"><i class="icon-chevron-down " id="i_HTS_'+ArrayGruposBebida[i].idGrupoBebida+'"></i> Precios por Tipo de Servicio</caption> --!>'+
				'<thead id="Id_HTS_'+ArrayGruposBebida[i].idGrupoBebida+'"><tr><th>Nombre</th><th>Precio</th><th>M&aacute;ximo</th><th>M&iacute;nimo</th><th>Tramo</th><th></th></tr></thead><tbody id="Sub_Tabla_Precios_'+ArrayGruposBebida[i].idGrupoBebida+'"></tbody></table></td></tr>'+
				'<tr id="Id_TR_Bebidas_'+ArrayGruposBebida[i].idGrupoBebida+'" style="display:none;">'+
				'<td></td><td colspan="2"><table class="in_tabla" style="min-width: 370px;">'+
				'<!--<caption onClick="mostrarOcultarBebida('+ArrayGruposBebida[i].idGrupoBebida+')" > <i class="icon-chevron-down" id="i_HBebidas_'+ArrayGruposBebida[i].idGrupoBebida+'"> </i>Bebidas</caption>--!>'+
				'<thead id="Id_HBebidas_'+ArrayGruposBebida[i].idGrupoBebida+'"><tr><th>Nombre</th><th>ml/Botella</th><th></th></tr></thead><tbody id="Sub_Tabla_Bebidas_'+ArrayGruposBebida[i].idGrupoBebida+'"></tbody></table></td></tr>'
			);
			//debo a�adir una tabla con los tipos de servicios
			MostrarPreciosGruposBebida(ArrayGruposBebida[i]);
			MostrarBebidasGruposBebida(ArrayGruposBebida[i]);
		}
		$("#tabla_Grupos_Bebida").append('<tr><td><input type="text"  id="Id_NuevoGB_Nombre" value="" class="input-block-level"></td> ' +
			'<td class="boton" ><a class="btn AddGB" onClick="AnadirGrupoBebida()" onBlur="'+"$('#Id_NuevoGB_Nombre').focus();"+'" href="javascript:void(0)"><i class="icon-plus"></i> </a></td> </tr>');
	});
}

function MostrarPreciosGruposBebida(oGrupoBebida){
	if(oGrupoBebida == null) return;
	oGrupoBebida.ListarPrecios(function(bExito){
		if(!bExito)
			return;
		$("#Sub_Tabla_Precios_"+oGrupoBebida.idGrupoBebida).html();
		for(var i = 0; i<oGrupoBebida.Precios.length; ii++)
			$("#Sub_Tabla_Precios_"+oGrupoBebida.idGrupoBebida).append('<tr> '+
							'<td><select id="Id_'+oGrupoBebida.idGrupoBebida+"_"+oGrupoBebida.Precios[i][0]+'_Nombre" name="'+oGrupoBebida.Precios[i][0]+'"  class="Select_Tipos_Servicio"></td> '+
							'<td><input type="text" id="Id_'+oGrupoBebida.idGrupoBebida+"_"+oGrupoBebida.Precios[i][0]+'_Precio" value="'+oGrupoBebida.Precios[i][3]+'" class="input-mini numerico"></td> '+
							'<td><input type="text" id="Id_'+oGrupoBebida.idGrupoBebida+"_"+oGrupoBebida.Precios[i][0]+'_Maximo" value="'+oGrupoBebida.Precios[i][4]+'" class="input-mini numerico"></td> '+
							'<td><input type="text" id="Id_'+oGrupoBebida.idGrupoBebida+"_"+oGrupoBebida.Precios[i][0]+'_Minimo" value="'+oGrupoBebida.Precios[i][5]+'" class="input-mini numerico"></td> '+
							'<td><input type="text" id="Id_'+oGrupoBebida.idGrupoBebida+"_"+oGrupoBebida.Precios[i][0]+'_Tramo" value="'+oGrupoBebida.Precios[i][6]+'" class="input-mini numerico"></td> '+
							'<td class="boton" ><a class="btn" onClick="ModificarTiposServicios('+oGrupoBebida.idGrupoBebida+','+oGrupoBebida.Precios[i][0]+')"  href="javascript:void(0)"><i class="icon-refresh"></i> </a><a class="btn" onClick="EliminarTipoServicio('+oGrupoBebida.idGrupoBebida+','+oGrupoBebida.Precios[i][0]+')" href="javascript:void(0)"><i class="icon-minus"></i> </a></td> '+
						'</tr>  '
						);
		$("#Sub_Tabla_Precios_"+oGrupoBebida.idGrupoBebida).append('<tr> '+  
				'<td><select id="Id_TS_ID_'+oGrupoBebida.idGrupoBebida+'" class="Select_Tipos_Servicio"></select></td>  '+
				'<td><input type="text" name="NuevoPrecio" id="Id_TS_Precio_'+oGrupoBebida.idGrupoBebida+'" value="" class="input-mini numerico"></td> '+
				'<td><input type="text" name="NuevoMaximo" id="Id_TS_Maximo_'+oGrupoBebida.idGrupoBebida+'" value="" class="input-mini numerico"></td> '+
				'<td><input type="text" name="NuevoMinimo" id="Id_TS_Minimo_'+oGrupoBebida.idGrupoBebida+'" value="" class="input-mini numerico"></td> '+
				'<td><input type="text" name="NuevoTramo" id="Id_TS_Tramo_'+oGrupoBebida.idGrupoBebida+'" value="" class="input-mini numerico"></td> '+
				'<td class="boton" ><a class="btn" onClick="AnadirTSGB('+oGrupoBebida.idGrupoBebida+')" href="javascript:void(0)"><i class="icon-plus"></i> </a></td> '+
			'</tr>');
		RellenarSelectTiposServicio();
	});
}

function MostrarBebidasGruposBebida(oGrupoBebida){
	if(oGrupoBebida == null) return;
	oGrupoBebida.ListarBebidas(function(bExito){
		if(!bExito)
			return;
		$("#Sub_Tabla_Bebidas_"+oGrupoBebida.idGrupoBebida).html("");
		for(var i = 0; i<oGrupoBebida.Bebidas.length; i++)
			$("#Sub_Tabla_Bebidas_"+oGrupoBebida.idGrupoBebida).append('<tr> '+
				'<td><input type="text" id="Id_"'+oGrupoBebida.Bebidas[i][0]+'_Nombre" value="'+oGrupoBebida.Bebidas[i][1]+'" /></td>'+
				'<td><input type="text" id="Id_"'+oGrupoBebida.Bebidas[i][0]+'_Cantidad_Botella" value="'+oGrupoBebida.Bebidas[i][2]+'" class="input-mini numerico" /></td>'+
				'<td class="boton" ><a class="btn" onClick="ModificarBebidas('+oGrupoBebida.idGrupoBebida+','+oGrupoBebida.Bebidas[i][0]+')"  href="javascript:void(0)"><i class="icon-refresh"></i> </a><a class="btn" onClick="EliminarBebidas('+oGrupoBebida.idGrupoBebida+','+oGrupoBebida.Bebidas[i][0]+')" href="javascript:void(0)"><i class="icon-minus"></i> </a></td>'+
				'</tr>');
		$("#Sub_Tabla_Bebidas_"+oGrupoBebida.idGrupoBebida).append('<tr>'+
				'<td><input type="text" id="Id_Bebida_Nombre_'+oGrupoBebida.idGrupoBebida+'" value="" /></td>'+
				'<td><input type="text" id="Id_Bebida_Cantidad_Botella_'+oGrupoBebida.idGrupoBebida+'" value="" class="input-mini numerico" /></td>'+
				'<td class="boton" ><a class="btn" onClick="AnadirNuevaBebida('+oGrupoBebida.idGrupoBebida+')" href="javascript:void(0)"><i class="icon-plus"></i></a></td>'+
				'</tr>');
	});

}

function AnadirGrupoBebida(){
	//debe introducir
	if($("#Id_NuevoGB_Nombre").val() == ""){
		alert("Debe indicar el nombre del grupo de bebidas (Whisky, Ginebra,...,)");
		return;
	}
	
	stock.AnadirGrupoBebida($("#Id_NuevoGB_Nombre").val()
		, function(bExito,id){
			if(bExito){
				//A�adir al array de grupo de bebidas un nuevo objeto a listar 
				var i = ArrayGruposBebida.length;
				ArrayGruposBebida[i] = stock.CrearCGrupoBebida();
				ArrayGruposBebida[i].idGrupoBebida = id;
				ArrayGruposBebida[i].Nombre = $("#Id_NuevoGB_Nombre").val();
				//Eliminar esta fila
				$("#tabla_Grupos_Bebida tr:last").remove();
				//a�adir una nueva fila con nuestros resultados
				$("#tabla_Grupos_Bebida").append(
					'<tr> '+
					'	<td><input type="text" id="Id_'+ArrayGruposBebida[i].idGrupoBebida+'_Nombre" value="'+ArrayGruposBebida[i].Nombre+'" class="input-block-level"></td>'+
					'	<td class="boton" ><a class="btn" onClick="ModificarGrupoBebida('+ArrayGruposBebida[i].idGrupoBebida+')"  href="javascript:void(0)"><i class="icon-refresh" ></i> </a><a class="btn" onClick="EliminarGruposBebida('+ArrayGruposBebida[i].idGrupoBebida+')" href="javascript:void(0)"><i class="icon-minus"></i> </a></td><td></td> '+
					'</tr></td><tr><td></td><td colspan="2"><table class="in_tabla" style="min-width: 500px;"> <caption onClick="mostrarOcultarTS('+ArrayGruposBebida[i].idGrupoBebida+')"><i class="icon-chevron-down " id="i_HTS_'+ArrayGruposBebida[i].idGrupoBebida+'"></i> Precios por Tipo de Servicio</caption><thead id="Id_HTS_'+ArrayGruposBebida[i].idGrupoBebida+'"><tr><th>Nombre</th><th>Precio</th><th>M&aacute;ximo</th><th>M&iacute;nimo</th><th>Tramo</th><th></th></tr></thead><tbody id="Sub_Tabla_Precios_'+ArrayGruposBebida[i].idGrupoBebida+'"></tbody></table></td></tr><tr><td></td><td><table class="in_tabla" style="min-width: 370px;"><caption onClick="mostrarOcultarBebida('+ArrayGruposBebida[i].idGrupoBebida+')" > <i class="icon-chevron-down" id="i_HBebidas_'+ArrayGruposBebida[i].idGrupoBebida+'"> </i>Bebidas</caption><thead id="Id_HBebidas_'+ArrayGruposBebida[i].idGrupoBebida+'"><tr><th>Nombre</th><th>ml/Botella</th><th></th></tr></thead><tbody id="Sub_Tabla_Bebidas_'+ArrayGruposBebida[i].idGrupoBebida+'"></tbody></table></td></tr>'
				);
				MostrarPreciosGruposBebida(ArrayGruposBebida[i]);
				MostrarBebidasGruposBebida(ArrayGruposBebida[i]);
				$("#tabla_Grupos_Bebida").append('<tr><td><input type="text"  id="Id_NuevoGB_Nombre" value="" class="input-block-level"></td> ' +
					'<td class="boton" ><a class="btn AddGB" onClick="AnadirGrupoBebida()" href="javascript:void(0)"><i class="icon-plus"></i> </a></td> </tr>');
				}
			else
				alert("No se ha podido realizar esta operaci�n");
		});
}

function ModificarGrupoBebida(idGrupoBebida){
	stock.ModificarGrupoBebida(idGrupoBebida, $("Id_'"+idGrupoBebida+"_Nombre").val()
		, function(bExito){
			if(!bExito)
				alert("No se ha podido realizar la modificaci�n");
		});
}

function EliminarGrupoBebida(idGrupoBebida){
	stock.QuitarGrupoBebida(idGrupoBebida
		, function(bExito){
			if(!bExito){
				alert("No se ha podido realizar la operaci�n");
				return;
			}
			$("#TR_"+idGrupoBebida).remove();
		});		
}

function obtGrupoBebida(idGrupoBebida){
	for(var i = 0; i<ArrayGruposBebida.length; i++)
		if(idGrupoBebida == ArrayGruposBebida[i].idGrupoBebida) 
			return ArrayGruposBebida[i];
	return null;
}

function AnadirTSGB(idGrupoBebida){
	//debe introducir un tipo de servicio
	if($("#Id_TS_ID_"+idGrupoBebida).val() == null){
		alert("Debe seleccionar un tipo de servicio");
		return;
	}
	if($("#Id_TS_Precio_"+idGrupoBebida).val() == null){
		alert("Debe indicar al menos un precio");
		return;
	}
	
	//a�adimos la cotizacion
	cotizacion.AnadirPrecio(idGrupoBebida, $("#Id_TS_ID_"+idGrupoBebida).val(), $("#Id_TS_ID_"+idGrupoBebida).val(),$("#Id_TS_ID_"+idGrupoBebida).val(),$("#Id_TS_ID_"+idGrupoBebida).val(),$("#Id_TS_ID_"+idGrupoBebida).val()
		, function(bExito){
			if(bExito)
				MostrarPreciosGruposBebida(obtGrupoBebida(idGrupoBebida));
			else
				alert("No se ha podido realizar esta operaci�n");
		});

}


function mostrarOcultarTS(id){
	
	$("#Id_TR_Bebidas_"+id).hide(250
	, function(){
			$("#mas_Bebidas_"+id).html("+");
			
			if($("#Id_TR_TS_"+id).css("display") == "none"){
				$("#Id_TR_TS_"+id).show(250);
				$("#mas_TS_"+id).html("-");
			} else {				
				$("#Id_TR_TS_"+id).hide(250);
				$("#mas_TS_"+id).html("+");
			}
		}
	);
	
	
}

function mostrarOcultarBebida(id){
	$("#Id_TR_TS_"+id).hide(250
	, function(){
		$("#mas_TS_"+id).html("+");
		if($("#Id_TR_Bebidas_"+id).css("display") == "none"){
			$("#Id_TR_Bebidas_"+id).show(250);
			$("#mas_Bebidas_"+id).html("-");
			}
		else {
			$("#Id_TR_Bebidas_"+id).hide(250);
			$("#mas_Bebidas_"+id).html("+");
			}
		}
	);
	 
}