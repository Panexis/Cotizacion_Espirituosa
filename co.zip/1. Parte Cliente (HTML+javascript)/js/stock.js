/*
stock.js

objeto donde se gestiona el stock

*/

var stock = (function(){
	var listarPrecios = function (EvResultado){
			db.EjecutarSQL("SELECT Tipos_Servicio.Id_T_Servicio, Tipos_Servicio.Nombre, Precio, Maximo, Minimo, Tramo FROM Precios LEFT JOIN Tipos_Servicio ON Tipos_Servicio.Id_T_Servicio = Precios.Id_T_Servicio WHERE Precios.Id_G_Bebida = "+this.idGrupoBebida+";"
			, function(bExito, rowsArray){
				if(bExito)
					this.Precios = rowsArray;
				if(!isUndefined(EvResultado))
					EvResultado(bExito);
			});
		};
	var listarBebidas = function (EvResultado){
			db.EjecutarSQL("SELECT Id_Bebida, Nombre, Cantidad_Botella FROM Bebidas WHERE Id_G_Bebida = "+this.idGrupoBebida+";"
			, function(bExito, rowsArray){
				if(bExito)
					this.Bebidas = rowsArray;
				if(!isUndefined(EvResultado))
					EvResultado(bExito);
			});
		};
		
	var CGrupoBebida = function(){
		this.idGrupoBebida;
		this.Nombre; 
		this.Precios = []; //rowsArray de precios
		this.Bebidas = []; //rowsArray de bebidas
		//funciones
		this.ListarPrecios = listarPrecios;
		this.ListarBebidas = listarBebidas;


	};
	
	return {
	
		MostrarStock : function(){
		}
	,	CrearCGrupoBebida : function(){
			return new CGrupoBebida;
		}
	, 	ListarGruposBebida : function(EvObtResultados){
			db.EjecutarSQL("SELECT Id_G_Bebida, Nombre FROM Grupos_Bebida;"
			, function(bExito, rowsArray){
				if(!bExito){
					if(!isUndefined(EvObtResultados))
						EvObtResultados(false);
					return;
				}
				ArrayGruposBebida = [];
				for(var i = 0; i< rowsArray.length; i++){
					ArrayGruposBebida[i] = oGruposBebida = new CGrupoBebida();
					oGruposBebida.idGrupoBebida = rowsArray[i][0];
					oGruposBebida.Nombre = rowsArray[i][1];
				}
				if(!isUndefined(EvObtResultados))
					EvObtResultados(true, ArrayGruposBebida);
			});
		}
	,	AnadirGrupoBebida : function(Nombre, EvResultado){
			db.Grupos_Bebida.ObtenerNuevoId(function(id){
				db.EjecutarSQL("INSERT INTO " + db.Tablas[Grupos_Bebida].Tabla + " VALUES("+id+",'"+Nombre+"')"
				, function(bExito){
					if(!isUndefined(EvResultado))
						EvResultado(bExito, id);
				});
			});
		}
	,	ModificarGrupoBebida : function(idGrupoBebida, Nombre, EvResultado){
			db.EjecutarSQL("UPDATE " + db.Tablas[Grupos_Bebida].Tabla + " SET Nombre='"+Nombre+"' WHERE Id_G_Bebida = "+idGrupoBebida+";"
				,function(bExito){
					if(!isUndefined(EvResultado))
						EvResultado(bExito);
				}
			);
		}
	,	QuitarGrupoBebida : function(idGrupoBebida, EvResultado){
			db.EjecutarSQL("DELETE FROM " + db.Tablas[Grupos_Bebida].Tabla + " WHERE Id_G_Bebida = "+idGrupoBebida+";"
				,function(bExito){
					if(!isUndefined(EvResultado))
						EvResultado(bExito);
				}
			);
		}
	,	AnadirBebida : function(idGrupoBebida, Nombre, CantidadxBotella){
			db.Bebidas.ObtenerNuevoId(function(id){
				db.EjecutarSQL("INSERT INTO " + db.Tablas[Bebidas].Tabla + "(Id_G_Bebida, Id_Bebida, Nombre, Cantidad_Botella) VALUES("+idGrupoBebida+","+id+",'"+Nombre+"',"+CantidadxBotella+")"
				, function(bExito){
					if(!bExito){
						//Indicar que no se ha podido a�adir, si ha escrito el mismo nombre que un grupo ya existente
						//alert('No se ha podido a�adir el grupo de bebidas,\n comprueba que no est� ya en la lista.');
						return;
					} 
					//a�adir el div con el grupo de bebidas
				});
			});
		}
	, 	MostrarStockBebida : function(idBebida){
			
		}
	,	QuitarBebida : function(idBebida){
			db.EjecutarSQL("DELETE FROM " + db.Tablas[Bebidas].Tabla + "' WHERE IdBebidas = "+idBebida+";"
				,function(bExito){
					if(!bExito){
						//Informar del error
						return;
					}
					//modificaci�n correcta.
				}
			);
		}
	,	ModificarStockBebida : function(idBebida, CantidadBotellas, CantidadParcialBotella){
			//tenemos que sabe la cantidad por botella
			db.EjecutarSQL("SELECT Cantidad_Botella FROM Bebidas WHERE Id_Bebida = "+idBebida+";"
					, function(bExito, rowsArray){
						if(!bExito){
							//informar al usuario de inaccesibilidad de la base de datos
							return;
						}
						
						var CantidadXBotella = parseInt(rowsArray[0][0]);
						var Cantidad = CantidadBotellas * CantidadXBotella;
						//ahora hay que a�adir la cantidad parcial 
						if(cantidadParcialBotella != null){
							switch(parseInt(CantidadParcialBotella)){
								case 0:
									Cantidad += CantidadXBotella / 4;
									break;
								case 1:
									Cantidad += CantidadXBotella / 3;
									break;
								case 2:
									Cantidad += CantidadXBotella / 2;
									break;
								case 3:
									Cantidad += CantidadXBotella * (2/3);
									break;
								case 4:
									Cantidad += CantidadXBotella * (3/4);
							}
						}
						//a�adimos en la base de datos los datos pertinente
						db.EjecutarSQL("UPDATE Bebidas SET Cantidad_Stock = "+Cantidad+" WHERE Id_Bebida = " + idBebida +";"
							, function(bExito){
								if(!bExito){
									//No se ha podido modificar la cantidad en stock
									return;
								}
								//TODO: actualizar la cantidad en stock.
							}
						);
					}
				);
			}
	};
})();